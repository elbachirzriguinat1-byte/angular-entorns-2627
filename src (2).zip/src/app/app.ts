import { Component, NgModule, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FormsModule, NgModel } from '@angular/forms'; 
import { Producte } from './interfaces/producte';
import { Catgeoria } from './interfaces/categoria';
import { Info } from './componentes/info/info';
import { Capcalera } from './componentes/capcalera/capcalera';
import { Tarjetas } from './componentes/tarjetas/tarjetas';
import { Botiga } from './bindings/botiga/botiga';
import { ComponenetePadre } from './componenete-padre/componenete-padre';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,FormsModule,Capcalera,Botiga,ComponenetePadre],
  templateUrl: './app.html',
  styleUrl: './app.css'
})

export class App {
  
  
   
  title = "Products List" ; 
  Productos_list= [
    {'Name' : 'Porduct 1',
      'Descripcion':'',
      'Price': 22,
      'URL' :'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmNcXlPOxXEq6qA1oIYYh5NSdxcx3j0iwwsLRmTLNkuA&s=10',
      'Promo':'',
      'activado': false
    },
    {'Name' : 'Porduct 2',
      'Descripcion':'',
      'Price': 23,
      'URL' :'data:image/webp;base64,UklGRr4kAABXRUJQVlA4ILIkAABwwgCdASpfAYwBPj0cjESiIaERyM1YIAPEtLdfOLcEMApkU8V6lVz1R+L/oI9xe5nxxYy7TP5h+Lv1P979rP+J4S/MfUL/I/5t/mPzI/vX7rc+1vH/C/YD2Gu8H+b/vf7of5L5JPvf+D6cfxn+Y/5PuBfq//puQ69D9gX+a/2P/k/4/8tPqG/vv/R/qP9f+7Hvv+pv/L/ofgS/nH9l/5H+M9t72c/ut7UX7oD95s+Dn2k9sEJ/8n0U5Om/XCy1hEv1fI6BoOFInieeYqIyi9DogA6KgUeMOkMS9TjOAxm/8nPuTT//7sChiV5fL/s24wG7fmeryw1UzdaL2Qbqspwv3MhWZEOnNxxAlC3XUwSfU0AWSiEdLDQk18dIYl5MKZk5ID9QrLeBbK3IS8P+KYxVZTf/uygJAE0Tp9yOURQzjaUmbNmt9dkAMNxh0hZ1pcbM4D9cx7cwmxWvlJP0kKQel4VndhaaGX97RH9TfEgdc9cUO6CLWqX4UyUQp92O2lFtQ3GHSFmg/5J5ZjTZCz0q+PjZ9uPoEjfdS7LqppjNUANc9slVQQvNcwJTsDHp9CCf2MajdFGzCmwH44X0m24r8ZAPC2O2AaJWGkce80ZnazQB7Bs8B6TubUQl+tF4NDvF/jLdShzI5PwOUj7GzKsQ0Sn3NHEAoASxR039aTWNjeYBolxdc6ggxelJfZ2e4MqxmHrVvf1oJuWuyX1DLLe6KSmawjt5gn+J5G9hCzy2xfVKRL1ODd2IUTtja4fh2E2blEYYTcKRgOPLvSiY4XPyahQozrqeHgy34Pu8iVIywNcNCqxDwXC7F2SgoTsogikGFkCRUyIXOZ2Zdw8ZkcT/S/0d/Nr7iP+xkmObT/gNXyZhao4/YrUPBKLW8u+MU8LcMeOnzj/plj2vwDzuAa37HnfaZRKXgbAwH5RyIGN0Aq6JGgAN2ChTUpcSzeCPYWslIdtLI/XkpoUlnrB0/CWttM72vPYnL6aoani13X7N//yHbquiba6XAgpusfU9irCkbGt69CstVJe0eMYCB05otam/qkdjN0zaEcWh8fR2uCp+lnolQiP++nLQdYyzhfPX94AJPxwGJ/jvxPGuhDCl+t5SUTg9rcYYypSdKrTbOHjoDC+kFPcrOkBHMet9KLX3q2v/f1ASmeAlmfQJ/1bvYaErvP+DjXXlCKDUyVb1JBL7swqpKiM7nYLdfYIL9kEN3ygWBzKkgtIJGEn65xcw9YAdX6ltBFBBOtZbptMUuQHE83dNhBBJlLLrAmqTzirzjY9ZCLSfgnADAwjFIFYNcow80ksGqpuNloyI1oYQP/fTPG9vIWN3rFGzYqkp79gOLq7ezmDYa0EOptTTqV+7zMKKd+FmzgOcG2umerFkA0o6oE9e7xUfBtJd76Nb5NUNYqLJxWQtsO3cUwc/rX5wMiDki+qyZCoDsI7G7kG6vpRJ8Y/B0Af1sQyMReHHsrCvzlb34IejesBf49rD+hlZ5xDcGM+nPzYNFoAKyTNutbdNNdy1w4Uo+t3gBj0TSk7MVm6nCQ9vR9DL4HLEcQbmr6zioNkxKYxAUEauNhDtnbiahvmYC9hRoiAvMrdhtgjQVKFvY41p//Qmfol5+Ridr8Z1rvgNlx0KuMz7eCZOoQhtDtZggdTD1jOQsqGRxJhrvFZacK//jwHrJKvEOPkiJ5lml0De5oEDUiTwdDGL74uJQCpb4Fs5MEPD5CtqZNJSB2gu26IqdLxakhW9mFEWfH01Q74qMBsK1ZoWPYkQ3pn/1+RRZ3eyIxbioOJcXivbK9R9kCjK5RF/7r+eb3k67KjSgUsa5Y9gE0KlCncvETM648DCS1C8Rn/f99i2OJQfN4swkJDN6snB3j1scKch0XPJkjp3Wb9Nt67lQDDEvO4QtP+GyvmHLtWNDU76ahTqqdxn/SWjLmv1TfCoxbQorLzmAsMtiUQXG+OkLuKqAHtecxfSXA7kvEdf9Eg+P9FzNxF76uSIeP2lYXaL8P8zb3t1MSqra2zUInCqLESE1bEvU7KQsYN5Jt5oQeTzOaU5umlPNBhugK3/2M4A5+t87psBjEs9PV/1dTgAAP7/vcf4KUTQ1MafWPAhhS324padioXSn24OsIT73tMR+KFOAhveIJJTHyL1IH66dozlYnVzI3GSpKvPJDClkPr1MoSpf50VOkNOhfuicZpFZUKsHb1SjpTfOTlBQq5iLzdoqM3YI8MfIl10zTYOhx7wIpPh6bgPaqM8JhFiZO4vQwPS4RsOKcCztj0rxhZkRWSZ4Ala/IpAuP0/FqH02OOOvsO/xmaqcTGeX8GhxkDWMRIWyLq3hkVDqByK8PpUvuhFOb7vm6dABhpsw3h1gUkivfhh2Ts/t9w8SfBwDZG91LshCpYkVmrZI2WeFkcj1EzPAzKgXjhW85hYAX6h3uEZ7/6LHjLy80TQIF3iHwEuccYO7yI/NTBDc3ABR4/chj8RvlzGdxXiBCjWcALeE8iAoll15N1FI+dczhP+uwOaP+ljyPjpQN5gJcuOrzkJ2tD8Dj9so4Xnelk/XauNH0+Pp/nxE4Q33y3+et22EcXRS06xHfF6XUy5OutoTEEjZvT5BBr2JmzuLVFvewhZtT167IUsG9r9fuB9/gVSUfg8ur5llaNVKjN01SwCGs7QAGgNbRYHoLnIf+24gn51aUDNkr30P/YV4IoaWzcXL8ALXMKHjoWV3UqUU2XKIkVYEdYruTdVLHGAOV4RPO7ncqKTpe3Qm3jjyIdMNc98sqIJNArJh6pOp75e7AABditzMiuRkEg9CqPeNibiU6wHTT9pWbBlPsV+jjl6NMnv9aFZBFb/yVoaYZKNCWEIno7dTSzFfH5tDsKaZqnSrQtTdm5YvfHuuqfc+HUJvD9d0M4njrHuL3t2usjW540ndIXWqpGlfwoBbqL2iU5Iw9yCRvk/rAqpzh+bkg8MBStvgBfI9TZLm8H3qJa9JDe7C7KmNiF2i5wEJhYrGIf8vUqa8ZxkkcowDwChi9cosMTruT8MEyJCz2EV4rpUPPXw4ENZTwmu6bE4UZwsQjio4dlV+Bq0rjHjjI19oFcohnE4vR5zCh4W15fdWEXzKVffUuOR+S4Kc1N7VUJIYP9HQOYvbgqvudurwE8h6ju29IHkdx563zqLQ2MNcvAjgbMIKVqwZlgGzBKr1X0WF+I8xWNhmzTWepLLBXaTuS65V5zD2mzv5z1nw/h8JH3X3opjvVASEMGzpyELW8JnJHPf9T4MFYnaVNiY2lA53loSJPbv6E3m3JIZ1+oZFq3KPzWSG5NZKzXhT1EFUhXE+ZwRykPZ0H7t2hI1BZOyy87cKqqjDqhhYaQwGn4GpD5aaUwGcm3K2npedK87hrMUAJH5x8fY7LQqjpyZ87iHynBelV6et9agZao4CCVsMjr8CZ0wyjEjNpOysaP/Rnw9hAc1AT3sVVyLswQ05Vb7NKgMGmUkyKGC9xSB8xD+mqVUmbUyHpAx7RzQKOEg0PsbqQlZI7L88us4nONMbDnRjJnWjIZcpOCMSaPR+7LzdW5FYmU4K4v0eJJutSFU0Kwwogh631L4ItcRkTi4hfaZ0UWCsTqGZ0DCnwyL+biboLD7wDCaU8Klm8WyCtW7xM7C3f9hAk7/ZYKIsDXqpFuewzcd0lOZuahIvA6VDRauiR4+dTMSzmZm2l8UrHOqtEAt0j+WLk+AU3eQYi0RdJSSEJdSqWhSfqjEr4vo6lprk8652bUzydkI1E+VFR3iunJDyLurWErvx13pouzLxKoD/Mjpa5qWoUXJ/FSZ2oigrWdNOb5fKbYR6L/1y8Vn5QKksSy8OhrGGFkTL8daYkkiosXORogebAqVTJnKEdxXm91FBTqq00VkvfiSaIBksL/o/1lK7A0WnvNR+fQiZwuINCM6LHXCer9/Lw9crA9rEaZmE5RnQaPCnixZhvu0HKCakkiPDNBAxmGW67sHeJJkLCM9KX5jXJPEkuZ7D0yh2PcJ2cpStgzduwTy+EcAbyDEdh/ltUcTiTXWLbFDyYVPdO3H+XWfr1rDWoW+Em+2oFCw7fzpzevl6XSNwpPuezAwQbLExmhbbyQjhOrzqdTHznV/SazcLR55BcV6DuAy/ZyibmgICt837+0Vc9YegSRlOvU0+TvHTCPzUodxy01GlSwRS1EsqSqud2V7VmK1dXsjhJergdShkLHNQpUDSGznkC7kslCXZbfXn80AvaSXgAGrEUr9vCg1Cgq2g0WiDB+p0kWhLPEt978qylkDOxHMRIhcm7WdQBeY7pm3ONtwhCaN9PwfA2oX+7/ButyzrZwQrPswXjCdwdueoBkpNZWnz9Oqy0hJSUdmIXVolsvF7YVh8EI6Fdm+sVy7ZbB0CeYLpJlZdz19U2uR9oUnJx0kIV+cqgG/RsFdmn8o7exS2GQcRNhrRiZIZpKdMODOde191EbrlgrUv9lJzkexafjkzwMCWhQo/d3f+8zIIqMpNdZXL0FPtXJj9RO2/L86PnFrMQbXGempEcHKgrkse7/GtPPNpLnau+PxKYbGfDeJj8cvKHWPg0fA4HlcsvQhusxEHDGqG4JtoBS8Bsn0ZtK81XAkAaKiZI41Nf7m64RsNv+bS3no9uQkruI0er/LjIvScZyxwZocX7jkgu9WkactrnF3fyFPYcDO0o/6Md1oqjR3eq5IDKUgREQ+DQTPti/B60n2DDETVBAnqlg00q68qFsJgnwc6ldnCOr8DFXOQh40lcZ8vNe8/vjCyIjXdbV2rhXwA8CjrcxRGhHHIK31VnIdfQbBqFYl1Ncy57nuATGvMAx7zmAPTfJVEpBzNp0b+FDB7Lz3EyYQ8lu3TUIOvyONCYEQ6uegZDdfrYaJ2mbkhW1UMT3goQz3190UarCiRN2OhRqhp0ha7V73GhD2U74FKJkoZ2rbsDX4qMNoj0egL7O01RZzE8IlryfTicp7E51k6KKGetju9JfoqzkEVL7d3t2kr1JShphOgzPCgD41Q9FgT8hOakTAIONPCZ4YRG7CeOtwMuyonOLcuvomVvFyyfOASh+0H21uWwZBODqX9RLBjSSDbH8XtwWARBwfZ/+28JJMcqRop8bhJk+AidB+eV7qbzTbRN16jlSKfWjtavOmfPYjf/hi8pQQyIisXWU6HuGPruIOKQdFGuKOa7VWSg2/jkTrbZjs826S2bQnIB8hgUL/fI7m3PDVZWmFBSwAHW9s8QUk3r4FHCKdpuNTmC8MjdoRlqPzxYL0z5KxzGPY8e7KoNGNKU57s6FpDztfHHBrcuaDPtTJReX0hnpqrYwnHu+hoVWyJuANURlIguY4on+xpNOL/4mzkJKRJGf3dK5Vl9twuay5UNMDF9NZTnivb+fYaudGit5XbtRZfzCaIBjKlew7isJx60x/F1ZeOwAikyLbettzXxC2miv/Bv+7ZXE82ernH6R+ZKFuK0errKDuQEGihZZojJntsFJH7H+EcrhNJpovrGdY416GH8+79pis5yf3nbzC0wKQmjdkw14XSvsMIlgdgIriaXpmjNDQwqlFxUHd0Em4fVP9Ejootx3ygDZLCp0Jf3z+vNblsCmnmrRB4JdcT5Y3DZcR6qfq5+99dPnQPejM9ETEXtcqLaI/gU1RPRrayeKG2Ny31/Y0K9bK9ekdKDfS7gII94xRbQLaKiue3gQXSKLJbvTdfGmEovctugZDce/BE/8g+u4j7MZNuFshj0W6XHAz2a4+gpUUqMaTP/JLXUpcOE/hC4V2pVzXFZDEnMmtp85w6SkkJ9K4Tg2/WHMSlGdCVFcA5Px4Ppn9wRdw4RqKxWpZtCZFvKFy0Ku6v/Xo+JtXXTux1SNLL+IjwbapBh1+RhPnX5G3TVFt81e4md450fEJkq71RxT+QNzElL1y4jCYoDNoLReU+kkHlwE+HItCv6/y00CD/Ga/e1sQfuptHFae/HRPJzmVl41hD5l7oqeaI/CRFDPCRG9RJiGJAQw6G4boJLSHQ13aXruVsCIry4Zcjh7kFhEyPiJNRXJ+3/See+P+p999YatUtW5b19EcPo5loZGzHZ+rnwLsU8NbPiekJSfpZqiE8EvVVBMveSvKM15iwAyG51/ImdK3XQ5azqLQ50Wvf4ufJXnDu6GFFS21tUvecTray0r96320huCCkKzP50GznnSdHPWyem9WDLvjsHZl3U8IbXA0oFWBmpqt/48JalVM00yPl0X51gT2HMopmKy/2t7VtcsDr4bdzOEtFND0A6oEr4E2XyvVcHfmmUlE0w+mLVt/My3BpeCFza35Yi2Qx/cH5/usvjFjfh7HwE/77Ngh3mTMjq91nhfiMyQvgADkDPj+ZL0Nq+mB5Fd6LEUe9DPcsWptpa+wTWwVLKd4LyiWPulEgrMaE7AFgYsdyH9jfHwVRxOxTKhd2qj121tWbUa0Nn4i1PGsBlbNu+GxccztYunHSNmAVp35pRWSmVFMdgIfPcFAyhDn0i1cWbYYRyu1OtY3L+Sty+GQqxIdp5eqHNnbBMF5+ENBtFwEFXcnnEIExEyfqvDPAAMa5sXWTCaJuHPYZ0Rz71/DnrkQEB393wPFO4ssbn0c/v2UW5pod3tLutOS0CW1hWrFk4Fdny2FuNvhR+myQEgwCfC8O5/7e7nAPs1pkqOIa7MyclGanK2KkBpoCiOe4mLyvZ2jxyv4mvde860+jgdY2L54DKm/oYaY/2lK2ASvCFhtGaHGhT9tFcQpOURgr5C7ADJ/FsCUxaljjiSMBHHwS7jH+QhA9ctzYaTJrdCxBRchCRwBRs8reQYIBkEmmrMnEBLKurYRjvI2ihlUNf7fOa8F0IgxBX27lJSaRyJN7MZGXf+B7bCgP9OcPI8k5v6dES7J6gtM0Xq3mgz+Fk+jwYD3FTr5X+HVdgYYEmJjrfZ6K4KrY/IYSZ3n1RmF9XCD4RZgbosmo7NjV2xTtIqPvvjhcBCE9gChiEw+RFFx/2p3hf0xy0kAGMFqy5m3D75YQECoJ0zE3+jv1fL13OTkI8bT7ZpGX1/8jdrGteJdEXsmW9x2J4r2OBkNDiESgXlwxIQGprK38rcFaNyBWFj9Xd6bL4LCi+OQE0jr9T8vYo69Ljla/AH0BQjBHb5pt9MrSqEws03YIpYqGd+/VRQA4P1DlzVgHatBtraaTZlQiTwMUuqauBBjXIA7pN8iiuVNaN/7wd6XX4xxRFOKQVxRvnvRxH3aQ7ncb8TsTxkEUhicwpCUq7Rc25/rEqg+eeJvNV+647a3dGvEOztm/pzWEMpaQmlNuXlpq30FxuqJzw3P2M4yLGLw6d2VQqTZNk3pmn3DfwNQof0LbxEAlcwE6zFNkf8J9ysx0FJ5BkzD/6LW1GZaxUm9oEXK0JnLjDWDX9zEcmK/5zsjIpiQ3e2juCq+TKma7p+/EmJ7xV8AT1QTHZpxEmORf7ahABd1nSnPtv1IgcEadNfrMZ7smsITciazHkRc5J7ceUzN21Ny9HTmzW/XhU7M5ASYwnR0PEgQyAXE55HAORmJFqR9CwfJw3naiOTalghbf2Rw3o42/DuhmKqjvmwSth213LdXR8CHEAI+D8fqwbKaIcXQfmKME7JPnkgu06YbgZWIp5C7sIp+tBBXIehGkLSMB8PV4Cq/y5OUZGJr/KjN1CHDcW+RWt6nLoUP/CADRa8nPRD9ZANQkMoQcD5Fz5QgmrOhnVVjMeELcsGNzTp3/4B072mHpBB+nu2pqNNeKuW2LORy8pFs7dXJZwkQYTE78da7jN1QEJuNLYQDynCxbMO31vm6F4Z4v8h/pkU1PmEs50xpg2QAqpMndRRjDpav7rA4akVaYlirAxk/uyNX857ccYgYLIrvu801P30NkrLKL6hfPZ5QLLz5UL6RdMOMc8WkP2aFXua+hgHRbFTtWpqJnZgRfG4qzhIo4ilEVYMjS9OG1hh7P6/HRts46MafkxUx0bD0BJSAdZ3G3sXBhC1fVlAozfpujjpKQspn/i90jLmTmPxNo45++CfrHfxAtmFLJlJq8cLf9orQVaNWc2s9jlxjoyM+fHOUIbE0Pi2U/G/D6UAixc2i2bmFYlK4cULVP8rAi7HVzUYo7+SS7P8t6OR48JylAJNaEuNwvaS+QsLGeIHAXmi+66J+NfI/YOoAc0RNatAGygPgmloeeB4vY//Lua/jRbexUNNuj/m15u6bTLJoGFt5q789qClJj6mE82nKI/9Q/r1sBUt2jQ0TQ8iyubgjHdtOLNekT9Q9/YERyoDvzw1Kza/r2+L9hp18YnVqe7rHYAFQErIDAhnQcFGxG76PYd72t6nzzWKowwJh4ZqfdB9VIw3Dhz80T9kgeSutBJ0E5i1U3HPBu4Mq2dmpo5ivK74TmgFgXQW4eRyXcv2n4bf2ZV4Pan7RpiAAYrquPuWLzY9vfgGecDxq8um54aFPsi+dgginKtmMeJEHcKOMznlQVFAgvW/iK/LofiA6GEiEixoA27Xe6YPGLkeIctwi6itWBghlmwINP36E9WLWipZpugAB4je+iq9WMZ/CXUezeeJq8Yvd5y++XHeQ8zQyu/2Ah+GXskXrMbA42CYJrgFChm3uXFj7+z7whHlBRzBd5LCu7wQGuM/glq3mX40MDLr8QiN4GR4xcdvXZzgXqfDleeDxWs6EAg0DwyqIw0S8tfC90zzdQtJ3UNMYWO8YpPTgwx/5ZJODHPW4xKpU1PGDh/7cXq78nXhHW5OH7d07pu4nCghRL6EW2U9BUb5MKcLSlP5hIlZQ+5MhxVhrhDLbk9JYp2BWAb4LlnYBnP7/WydLdXhAizY2a846PnGrPFUwn619ohpDNIp9riWTJNuC7JdnNGS+rev4eGfVrgtTUAjOs6rv8w4+sMGRn1SQEjURqe7zDt9f8MUPb6T3aSdrCO+UJv3S/H68znaVhLw83znpHiUxfyDsS+snCjduJwgJnViAiKVF8qiFfcxUvybiDN2KysSC0Le9mb9V2rnaZG7iJ37xNNlcPFoLpUpvFI/x3LpGt51Z/ufoN/XZ4ywhJw95UoByvosq5ajJKkQO5aNKBRo95R272I88R/iqi5djAhGjoC2r5xqo918IZ/9DfB8z3BIRHYjFAaQv7KNsq8fH2LibD3SQcMxS0wGf6NR+TXBljBSGmX85f02AKV/VqLC0oihblL3fgC/yG7+xVpj+c5CIDnoidwyguEEZOJY4ZIBR40oR+jbeMeYbvmXWY9aXevTpaC70I+XAv6F/tA3rzcN4+FqPSDu6zw+NMmzVb12AYFmFrQ00DLjgo2vcYIJ/xIVcWxH7DjKpwuRMjjqtz6cLmXqrPnO0ZOLlxsN/QphbB8eH6gizm63nzFc6UKp0G3v0VIqNg+yZO0J5xksUTmbB9voNdyZd9UEQuMYRgnfDMUgc+lbnM3GXZN7EWYZFizyAvlng3MsWqyhqOfinXcxFukPbfT57H17Z+EiNW1lOitkr2Z36pTT57iRG8GZvJ7kVNi+VvqfLul5+mO7fKG0AP1srfs9lLSIMnwp4329M7VBpVWAW+x//wuHrauWtHW+P9seaB4m4ZF6884kCOxWPwiVT5/SwePK7G3aMdNCfCDhr1BR/9Nyifnlu8hcXe7JDMwDGWGLnsr8TxYPkuhn9wf7bp8xbmT1CWpvdjcDGNAH9xtI2MpQfuXx5JNi1fgI4K0re0DXFFOxGRpZ4qUaBea9YcsPq632IfhasBfMpXH5V73CAvWLq4VVn6K5GlIuWK5KPeGpfOt2V3+ae4iQfZEZmh9YhiwLhBwB+rvCk3mfYcY8cGHKPxidPGh4YE+9OIayTotX/Gws75fXy9vltpRtst4iCdeohYqXTm319yD2haqvjEkpAvRB/SRyMntIJmbv/2NcjD+THMZdsGu6jhOD0ovpr5LlS9bZxENhDm1CLtwC0I4b3MyfG0zCebAFzZdSlJkhLzKa3xZgavBJ/YaEEp08b2nFfimGGTrlfaO6PNVf3QKp5apcs9DN3FXfcEiqxPBXuh2k8XHvrmVp6IL+o8FvAgSdhJO78eUdk3iPYbyUWSXi1HA1hYsKWBkUAhPEV4rN/cvjiZV9Bf6YJAyXL7p6Qqx4bDzSqqm6ZQqm6ORyy0iEMcxOGmjeWrWyeSQXlzuOVq6qD6wv6N47wn+apfwU2nTOKQt5GLgRIGcNreeW30n+2OWR3lt/72Fqp+GeIpLkZfc//km18j5kb8MkUBEcr2TplbbDOSiamqNldT0wG2AOjPGbIuIOZEi+Q1EzKsDMckwIWrE6MyN43Et3Z1cPvTGH6VXSDmWADML+3uzoojSw3+9DEy21p94gcolpSRDVr3l46vfw/tZZerZUY8J3Ar3fK2kAqKqgJnJjlg08/F0FF319BnknPrRIN7OyiNbz6cG4GKlL4z25UCKjyg/ijwziQp3IptLlsFl134xgS/P/ZUjjqbQiFt0jp69NUe4xKBpcOQEirFPQtin2hrwiL4vkE/AUei0F7LS291511S333sa2Q/Q98IVb8VMRk5n7p/acBgmJ6YWKZthICsFABTnX/u0OOhSipqghhkYi7dhfVCO9Mcha+EW8AZqD3Z0BtUpTUGMeo4YRGMiqrvmXfUGMKvwLtMYL7fgYjAhqoFQKMA8i8dl0cTsgxdqlWskovOSd/DAgqi2prhD/bPjfuE+1FD8o/jFOko3O7+OBHe/xckIh37Sljy7v3liq5536X9CWNWm+82+4BCwoyHu+NExfvkFtx69gexC2LFQYdUVNxcK5JkjoWICN+0n5ZQ4YzW1642B+Opsx540+WF8mNRF3P+1y3Yp5MwvDf3+a92ruzdETcYCFpPXjYb3ZbczVQLlBquL29icWXr5m40d38c7IX9kkKzob4s314+yonr5qkNst69ObD/oxdzfLnIQzKPj1CnkM/4tQoGmLIoa/Y+udVVruwNVRnp1ykhvJPuUE6Rtb7UyalXeVYyQg2sFs7UdxeJ1UePCgsCUFqMnkhmdV5x0ynAKGBPiGDaRl/WRA30+48ZCy2s9FEkZ7cFTPm0pQuYAGx7tzaoZ82iAxwk/bfBnHEVFKcwuWti34Lm93wIVyTNTtMRrQxHBaAa0UJj1hsiL410O6WzB7JUs4cYYTnAKnuswKGEKPlKF2eBjN83kBDxC21qwVMAhjYrvHrzilf1JXS8HWi4owGaWbr9wnA0jF8WS9WPB2imVJfEqyG71qG6/z3yvjhtvY8iKADbyKgVHr3K6Apr8+Vzwr7LQtGkBRqE54Tcc+JYnH7hgy0ixG1Ls4n/95aoDDllvxcdPTmikzg8v3GdXCQw60PVRXtdQYfBsBu5FfXWbSKCE6fyXKCdP+fA0Lb5EhEWWtx90k58ZCx3n5wEZO2HpzAAiP/YHPYZ22GR8JqtBxLy+f+Mo+M2yPVu4kFKCSruaPufQJxX6O4HmmooYxS8IQDvVLBI4vfoN4ebu2XIEZs/lB08yooiVXpAAA3ifOjHSdwJPfJABzYbDuCMxPWBmlMBnLnLqsY+CBeeQB4sWASnbXKqp7WFfdMDOGxrcMAaZ4/spf6gXkcx0RXz88WllfOuIZ9ph4Lk3F6rQNMwrOhMD7ixadWWv4RiMLl3YitKKsrL8a1DVx63YF/v3jNrbfKx048WmF/Dln6rwAhzMYgiE2lR7PvlH0CV7kqHuZ0L4XgZXwGaFgAvfljhzyqVvd6DxwAB/RMSFpOwbAF3R/C39M3OzUZU1risaiwBEcXS6dcjiVugHrwq0H6Az59Mk1eBWvHjHijv12X3C9yTwaM4j3fsSkTtcbMurrmlPuWtJwO4iaRSDrsTPrBi2a9Ou8rgKzc37a0M4ExZma5Wq6RMtM+BEspQSlwf88f2PQWoeRYXX+DnGYmp+frwn/LuXbTy7wHCy41Q12FM6oW634pdt9QDrbRJ/SNVZ3XsXmcvdvOcY1PbHFCmNEzCd6vuF3ScO9YxuOXyQI07/1zeBFoQkZmyA7WctZwMUV9vFPfAAnPSzJ28gxuLeaTWBdk7jKAAABK1yG4ggwE6L2/uT8sfSx9ZmrfMDsj5WzWBs4xN/WYQMgwHggwwrTDQ/Jl14iAHPglDTJWL9mQNjB7G5U+7/drcgFicV3ai+rSOhydDNGQXsX/cdMndqpr6LfWPQ8rl6FLRQkTec7eeMjXI0JynT/QNlmo6K0Z5poce4pcziBsHVxH3cK+SLJgns47bBJxClHsxQ7O4FwKX6uxntfyxAAExTiXULU7mrY+mharU1tB2tANSL6EyblnNE/rOlMEumVgF1ekXgaBlrTFl3xthr7eTF39yA5/07hdn4LR1UASnTzodZxuj8WV7BrHfremxesro8jKme/ylP2R4KHDokgIOgQz2JpScf7l0XJO+Yunh4nMcsvU1yAAAAAHcfvzAOnWat02DSpssAWD3h1rr0aAx6OazAVpoMopjALkajNxEChwA2Shc9irNDpUL6ggoRpkI+7piBOAIb3tJrIPabtRH/j5RlD2KJAg1vVPXTZNopdYa0nrQlZ8jlTPNHgwoAAAAAAA',
      'Promo':'',
      'activado': true
    },
    {'Name' : 'Porduct 3',
      'Descripcion':'',
      'Price': 24,
      'URL' :'data:image/webp;base64,UklGRhIQAABXRUJQVlA4IAYQAADQZQCdASpfAaQBPj0ejUUiIaEioJqo8FAHiWlu+uNL90tX/z5QQJf/5fxrVwUmZpN/ybZgJcGHw+wPrs+0fNmiWcj/Yf27/K/+/8om896T/pvQI9bvpv+z+3f4u/s/NHuWv+H6//87xgPtP/E9gj8x/+D1GP/L/Qf5H1bfT3sIfzz+tf8v1zvZ36Mn7SBYxxY9ZmK2A/1mYrYD/WZitgP9ZmK2A/1CRi58znm9i5i4VOBp/rMxWwH+sSt/K0ssbxJ7J11K3kVI8ZskXH+szEVwvM63nEyOljAYAK0cWPWZitRtq/v+IPKEmE6wOurdhHDFNR4pTNQxtFXiQAExqK2776BExWwH+micArnwvC5BIzgp+Nz7aH7giYrYD/TQKWGmfE6K8vD9dmYrYD/WJYsNidXW5bXCMg56QRK8hqOLHrMxVZVo2xsPALmPLd59RKUKpc8ZY4JMka1oCcbdrOA9JYwvs1hqYrYD/WZcGzD16NRD2NcY9kf1/evK066E+t1NRYcMzOFY6L+mwd+sx6zMVsB7215QRCW2/SHt4TIVg7DQxIF8cWPWZiqxTnUfamn1xnsr9aKXLdDZIuP69kAWSYXXaBfG5lyFtyjP+M2vIFqmdeXZbiRAALj/WZiLLNZ0NwpcCzjinJK7n40JiMXthIsUAUEOoyxV1lQGbwIER1azMVsB/Xs9iv+MHyz1nHbIuU3EYKGuFNOKMmr3u8ZvY2YHqdQFMdcxSGCwyjIETFbAVJKQvnFFXlFWV2bqKRU0d2yATXocEwXUZ3zTXwGimAf6zMVr4ebk5K4P51uKaaFNn05F0Tx85ZTuR6xscO0sUEM43z+szFbAe+R1qui5SjnHgaAqCt7UkT3rSp3nm/rMxWwH9czaf6MxrZ+nkBtFn3Q0nYKokkABcf6zMReiUseHfdo8zThxo1r2gDm57E6urPMq+WOXNTtTTHq7v1mYrYD4WJZFTxgXjcdIDZKS34iQcRVRbAf6zMVVAhsAxxuB3gw2oNXNPzA6iyqZ1olmDGmDAT02tdUx8ZskXH+szFx8oZskXH+szFbAf6zMVsB/rMxWwH+szFbAf6zMVsB/rMxWwEwAAP7/2WIAAku5asdBRx2UbXwNwjP9rBYHArDUrrAE7litFe2Z5MwcVnwtNEbV6XIgTKwH9ggUAr2v9mjl/dxEyf0HTMbIvISJNyxavDuLIgBkB9DgUFLyQ9Kj95T4K8IkCVVatU87mXthH0qfkXhrojYT8mePywdhGQdvCpOejR3c44iQlCngXnDUvSCx83kp1hY03zWqv9CwXfAPT3M4euXxQvAhMGqiUextYDnNET+WSpPTstW616hccC0h6rI04i58U0EDlxAxXN5AE2sBjCHKhpl9EsuclFk5GKbr5OkYNRmgieCqcR9ykrsFpsUd+yFur/Pi1/63vp2bI3S2yjBUejhdnkhosVIVctD0Xfy5+kAZ/WX7XitwlBPTrkx0QJchpzwRGQtf/xz2FdB91zZtSsLlP8x1LHIr852D9HUlhPWf2Por0SSSLQp4b7GAEHP+NHLNKdixoI1OgMJFAh4IECCb0R2+Tr4vGvK46kiW0FbONnKkSndWt49Pxqaksxmb1QBdyqPfePCR2aQCJvLX/eobv383fuOVAT9VsAyLOGmmxHD2zmyWtwr2n0l3eO/tt0PiectiU7JoBjElSmHYHenr/D/PC3CO66++QUQqemD0w7NJy5VEzrpjJIoJ4mJEKMlz/TrcsS6b8wYspldJyUy0j7Wzf99hj4SQ3T/CrbSPrjr1yAW/JaWclR/tXeI1rthJP1h5Ap+WlyBi93Yvc1c/yyTeGWbPl91Bi/ZhQ6XV0/7BGRbi2q6L+A7qZRtyeN9+iPX+EBMZnOyqEma3Tl2xziNESmj1XtcALY6V8C1kQvaVGNbY5jhbChZFeFsdOGXboKFif5r7N/8u/3vzYQvby5nIX7jzf+RQ/nbr90n79b7W96jlMQgT2nHovlWJdw9oGKt1F2M61O0aeKoup63MId6uHfs9LEPs1fFjb4v+tGkyW0QrmYyJsItkcHtyxKQY7hjOzFsJWoPRtuug6cMNBbMQhYFjEzQienJc4Y97r8YavIj7n3aMVQKGa0K8tePIjsxSy2v2LOtH6p/zQ/fFqygP4vn+rx4VPb+/AvVGkhV3REIL+VlR6gLf94BTYgv+Lr/e3VTPhCmXSX8s73ytt/hSpj18HF0YS3aFdv1JaUsrB2E4+3fxv5DskoV/4EovmFORMF03gG6nndnv0FEeJp/47buio+u045SlQ/0VfiF3bccy9mFXQq6LrSaLqabj+DWJG9ENkPRcjqeXYFFEChBDu9mhkN7L0yYvd1KoeM0FUf2V7WZ8dixYTbJvSWrJg3d40Y2QkLqaOhLIp7/wuPN8huBi9+8AE6tUTlbifbbdGfaCRWTW8qI/PMRZuE5Vl6MubLlVqyU0uIrBZARuw3ItgMhaFbpqd4COXZBBvOrOXpqU8NcrrtGfB8d6zTIiYrl7sckYQHBYSAXZ/LHehXPSXcoDkclcWfeh8DbvkTf9cjRuScWdB5iBUnhcAGNNPkxH628CpQvse0NjsLsNXhMiOXIrM0yMHpQmWROwLPxsfDsYcFiIgiANfLx54EeEVck+rXRp3MtNI8yFzZ1OvUyl0uyiyyPgbR8PD7CAcP0fQ6wOp16mUvISQsZ2tTvYviOXyDcaNenpY2+R8vOq6dbhfwidsXtLOOatXoupQfbnyU1VjdeXZAkpGtfcd38VX0nskpoZL1Od83uGw/AAOl0BdqC9/Us7LZXCR2V0eHmpJgH5V2sUI6Zhptlc7axOwig8H+q12OKHsvL7aalm7k8keg1UXT7oNKpfjr/Y73hBMLBU21BmGIxmiJt5jn+nMgLcD3t7LF+ICIMTr0Y5kNXzE/UvV/xQZsMVdbNoMzY0nbnRk9WfBMN+/PasTjTsU/z4bS7D1hwgqTMyjiAhD/Dy46qf7VoxfIfpeCnql+2EGzm3MyosbNM2lfmSeeL3snwcttlXXUH/iVxAcw6rCKPYWJCMxFwylINRT96xiPXsr4vTM0Me8FIvTuGHG6g0aqUOOpuCkCE+7HQp4FK/qPbazTRHN74riNp2H/BdMjkNzt9MR8g5/VM9t/ILl5W9Hp13+yuVvgRpV6uvnM++6pNvnuwi1qyNl+EK6CWC2OyRwTJQVmPc0o6TJVDYnHnk8v/TQgjYv1AZ9OKQHrRKIjCbptVF+UP7myrJ097x/F8h+rOzRp+mP4JiXvTe4oY3rYQ97fX6todxuhCNXrylLxCyaFB6tNIRF73YMKTvvDRgRN0wh0a1gLTeYOHP+Gv37m1ux4yIxbYo4YemO9Ns7tnejKEM9D/xwtBOxdjO6xeHtrCEkXhN4oxar9HCwBM8E3Ki2W60pD0wPPNy5mhdCE1gsMwwDL70VFP8zPGm5Vhf1GnABCVS0JNUfqiHm3or22m5JHquimyteIDBf8MjxO3eX6sEGfrcla2r5m1/+5Y82eVX/jVuyHcegiiEI1QBPTlJhvqUzYskna4Vs9edQawtuRxQVZ1c4BSmLZ0UB6yTZR+lpUZTUEi5cP8Cd5tCnJ/Qr5pNSCbHsyRHZXv+Nrs4RMKqKQeOY0is4cHh7rJSWZm7dpKFNmc+IwNNckNSoVtQzt3+gZPozuKPOB+OEa/+fKjNmP96O/qed3nH6tmnKyFzJK7e5W7u+enQttKaUbyEAVnJ3orLifDOz584MWHl/b2aRZp/FFTuW5SAdBz3s3Y2RTEhdhLIYub67BpcghGcnLUobgDyDgCfXhg9/6NzzZ7mn7f8vmjhlKvwZgZyDHVKcKh0aIl1EJXgO7B1YW2tp1ErXMGUc/qn4qQkf5VEk4C+KEP50splG474stlN5ZVHAZXERCFSI5sONmnQkNjMBcQ+pfDs9vO91goF57p1xE6S8UVguqviFxQlaHkR1l1KFWNEj2LtOyOHy13TeDq3W1y/nTZZf+mXYaTZ9fO8YS6QeU4rehjF/ixmExlq5+Yy9Evwn5YYWzzbi9VgcG1AAeVVZhhunbkXcfnaS97BoYgQH1nbw+Nr2zTw03Zb7FSt6XLzlfgJwq1axqw02ZD/t+4aJF5eAoyv5CQdIjRplmaupeBMP+NtBzJFcLctiESxjZ0acr2GshSw9xywP3I2rkYCtKpGUsLQkj9EJIq13561CIYsDb4inaSM+g2u8fW/Kh45fXgedn7QTokOEaOanITnS3jVShAgaqvA7NzXxobVADtuko52pp7w/nmbDoSDY4Vg6RsBUqoht3/baHa+Do8S7l7Oe6k2mr3LGqOK6QNQE+a7ogjZxiK7rnG/ctqV66hPBCDTkuV2roqe9Rh9pJr777cUheanP8KjC0GBDZgEV3Wx4AuYeDy3InzwYs8eGzYv91uGznsMfUXeV0KcQytoHJsxQOv0sK/EmJ9yjhA6+ygroHh9Md8d1LZ+Z7TZvhi1vfBoD9aM/ztO//+TEK9NQd9u3nYb7n/b+i37Lb2jC/RwPj+ckUaj2NjaGxtDY2VopiIxabf5rmH46Rsos/MFwuewiMhiNcIcnXr1+/frVGLdx50xZ/w6ceDW8LarKdNcSNWEwz6skgU3hX/ToqnWSVspXrkLs0ccqwSs4LPL3kRG2q4HyOFsT+gk/EYZfrYjlAbYcn3KWFKDLbAeKFB/FRgMU4JvpXqaUnK63n5GPJf148UexViuGC2AnKN0XJpzi7vojMu46Zo4rcGh5n9fJeq6g9KDTsGoza6c4CCRtkluXyeG0hfRhcnuUXROOzCZME3KFM9yKtzMuFCqZ5W4rtLbUEEEKR+NQSeeOPfSiSsiBIW7d3g2l6NwPsi98qcI8EKMUUCL7vEeZS8JpoioBgJAA/ezEJOYFBd/55laPaWJ9KEDSK3JMwC0yV3agFH3iCT9NPyNAa0ItjPV4bVnrMCKIU8cwXiN8FYBpnYmZ+HvSM0aVDy5Bg06pjSFtM0uP+WCrI942nOeCHuzH0H1z8uVgfEN+1AqxZhs5WcWnK8gHcBi2kERUoABOdxs+cAZPHxjVTGNyHIfIZuac6Fo3qHqDxjIm4je5GZKKAkys1uO6BAq5yrKLBSntotk1EJabehFwfTkCfvpO3KH+tzt4B+tWqMgGQr4J/IBXmayfZmaC5DmKa281uJPXqQu+3bdqQs5hZaugss/8bYBUNC+C3T40l5fAcJzLxCvByG8ulY3Iaz0BqEckc3xo27MeeA4cBqjXX2wpxfPTXQM2OgEre0CkpmtI9lxqQwEj3uus9Wn8TLjmPfWohkj+wOW+mLZPTlCvj1QxrjQ1K2TB1CO53sp3dRIFaei+Cp3cbFGGomp1mzxu64sdz1RtcobYzDjCLaWdSSaLuoojJ2yT08cctWXGBn1ZXUSCpQYXf+ae3eCX/4xToIdH8hD9OMK1lAOwjHc57sOFlRMAAAAAAAAAAAA',
      'Promo':'',
      'activado': true
    },
    {'Name' : 'Porduct 4',
      'Descripcion':'',
      'Price': 11,
      'URL' :'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1ZXTTglu6XbhhX51s5C4cvnEFWd3HpmgJTJWuy9ko6w&s=10',
      'Promo':'',
      'activado': false
    },
   
  ]; 
  
  activar (request :any){
  if (!request.activado){
     
    console.log("Estado de Porducto"+request.Name +"  estado: "+request.activado);
    request.activado = true ; 
  }
  }
  ciutats:string[ ] = [
    'Barcelona','Lleida','Girona','Tarragona'
  ]
  //Array de Objecte 

 


  Prodcutes : Producte [] = [
    { 'id':1,
      'nom':' Motor v4',
      'preu':500,
      'estoc':28,
      'categoria':'Catgeoria 1',
      'foto':'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYcdH9RLVpqp_ew4JxwLHKYzeJ5qoRZMQt15CMlN1f6A&s=10'
    ,
    'disponible':true,
    'descripcio':'El motor V4 es un tipo de motor de explosión de cuatro cilindros con disposición en V. La mayor complejidad mecánica que implica su diseño con respecto a los motores de cuatro cilindros en línea, hace que sea una configuración relativamente poco utilizada. Su principal ventaja es su disposición compacta, lo que lo hace adecuado en aquellos casos en los que se dispone de un espacio reducido para alojar el motor.',
    'special':false,
    'Favorito':false
    },
    

    { 'id':2,
      'nom':'Motor v6',
      'preu':0,
      'estoc':250,
      'categoria':'categoria 2',
      'foto':'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxXpd8gTnsDOBcUkdNLc5vJ9fEwmkS357J7cL4pjoYAQ&s=10'
    ,
    'disponible':true ,
    'descripcio':'Motor V6 es una configuración de motor de combustión interna en la que seis cilindros están dispuestos en dos bancadas de tres cilindros unidas por el cigüeñal debajo de estos, formando una "V". Estos pueden ser tanto de ciclo Otto, como de Diésel.',
    'special':false,
    'Favorito':false
    },
     {'id':3,
      'nom':'Motor v8',
      'preu':101,
      'estoc':250,
      'categoria':'categoria 3',
      'foto':'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQYFl8GynNbpQC94f_yEx61DKup5bDwhMMTBWEJuF4IiQ&s=10'
   ,
    'disponible':true ,
    'descripcio':'El V8 es una configuración muy común para camionetas, automóviles de gran tamaño y en vehículos tipo "muscle cars". Su cilindrada en raras ocasiones es inferior a los 3.0L y ha llegado a superar los 10.4L.Fue creado por el francés Léon Levavasseurcita requeridaHa servido como motor principal para los autos estadounidenses desde que Ford Motor Company desarrolló la revolucionaria máquina plana de 8 cilindros en V para su cupé Ford en 1932 Desde entonces, Chevrolet ha producido millones de V8 de bloques grandes y pequeños, incluyendo el estándar de todos los motores, mientras que Chrysler perfeccionó los motores v8 en una versión de Hemi para crear autos de más potencia',
    'special':false,
    'Favorito':false
    },
     {'id':4,
      'nom':'Motor v10',
      'preu':19,
      'estoc':250,
      'categoria':'categoria 4',
      'foto':'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqvLcYhBjNbPju1sKAqEKd-gH81PlDTNhpISE0Tj3p0g&s=10'
   ,
    'disponible':true ,
    'descripcio':'Los dos filas de cinco cilindros del V10 tienen normalmente una abertura de 60° a 90° entre las dos filas. Cada fila es un bloque de cinco cilindros en línea cada una, con una configuración que se caracteriza por su funcionamiento sin vibraciones, por lo que no necesita árboles contrarrotantes de equilibrado. Por lo tanto, este se caracteriza por su mayor fineza de funcionamiento debido a que las explosiones de los cilindros se hacen en intervalos de tiempo menores, produciéndose una por cada 72­° de giro del cigüeñal en el caso de un ciclo de cuatro tiempos, lo que también posibilita el funcionamiento del motor a pocas revoluciones, con menos de 1500 rpm sin vibraciones ni tendencia a calarse.',
    'special':false,
    'Favorito':false
    },
     {'id':5,
      'nom':'Motor v12',
      'preu':10000,
      'estoc':10,
      'categoria':'categoria 5',
      'foto':'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRoJ4LGxDGvxKohzMwRlBlEvzmds9UOR90Nj_6fhlDd7Q&s=10'
   ,
    'disponible':true ,
    'special':false,
    'Favorito':false
    },
  ]; 
  
  categorias: Catgeoria[]=[
  {'id':1,
    'nom':'Motor V4',
    'descripcion':'v4 motores '
  },
  {'id':2,
    'nom':'Motor V6',
    'descripcion':'v6 motores '
  },
  {'id':3,
    'nom':'Motor V8',
    'descripcion':'v8 motores '
  },
  {'id':4,
    'nom':'Motor V10',
    'descripcion':'v10 motores '
  },
  ];
  nom =''; 
  preu =0 ;
  estoc =0; 
  categoria='';
  foto =''; 

  special=false;

  addProduct(nom:any ,preu:any,estoc:any,categoria:any,foto:any){
    alert(nom+" "+preu+" "+estoc+" "+categoria+" "+foto) ; 

    this.Prodcutes.push({
      'id': 9,
      'nom' : nom,
      'preu':preu,
      'estoc':estoc,
      'categoria':categoria,
      'foto':foto 
    },)
  }
   
  AddSpecial(Prodcutes:any){
  Prodcutes.special=!Prodcutes.special; 
  
  }
  toggleDesc():void {
this.special=!this.special;

}
AddFavorito(Prodcutes:any){
Prodcutes.Favorito =! Prodcutes.Favorito ; 

}
  
}
