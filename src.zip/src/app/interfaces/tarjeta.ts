export interface tarjeta{
    
}